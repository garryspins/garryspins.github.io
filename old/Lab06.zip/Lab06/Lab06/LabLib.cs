﻿
/// I got very bored (and tired of writing boilerplate)
/// Hopefully this is well documented and acceptable

using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
namespace LabLib {
    /// <summary>
    /// Contains everything required for terminal text coloring
    /// </summary>
    public class TerminalColor {
        /// <summary>
        /// Where we want the color to be set, or reset
        /// </summary>
        public enum Type {
            /// <summary>
            /// Resets the color back to default, black background, white foreground
            /// </summary>
            RESET,

            /// <summary>
            /// Colors the background exclusively
            /// </summary>
            BACKGROUND,

            /// <summary>
            /// Colors the foreground exclusively
            /// </summary>
            FOREGROUND,
        }

        /// <summary>
        /// All color declarations
        /// </summary>
        public enum Color {
            BLACK = 0,
            RED = 1,
            GREEN = 2,
            YELLOW = 3,
            BLUE = 4,
            PURPLE = 5,
            CYAN = 6,
            WHITE = 7,
        }

        /// <summary>
        /// Bitpacked decoration types
        /// </summary>
        public enum Decoration {
            /// <summary>
            /// No decoration, default text
            /// </summary>
            NONE = (0 << 16) | (30 & 0xFFFF),

            /// <summary>
            /// Bold text, unavailable on cmd
            /// </summary>
            BOLD = (1 << 16) | (30 & 0xFFFF),

            /// <summary>
            /// Underline text
            /// </summary>
            UNDERLINE = (4 << 16) | (30 & 0xFFFF),

            /// <summary>
            /// Highlight text slightly brighter
            /// </summary>
            HIGH_INTENSITY = (0 << 16) | (90 & 0xFFFF),

            /// <summary>
            /// Identical to HIGH_INTENSITY it appears
            /// </summary>
            BOLD_HIGH_INTENSITY = (1 << 16) | (90 & 0xFFFF),

            /// <summary>
            /// High intensity background, does not use the same structure as the background type so it is here
            /// </summary>
            HIGH_INTENSITY_BACKGROUND = (1 << 16) | (90 & 0xFFFF),
        }

        /// <summary>
        /// What type of coloring are we doing
        /// </summary>
        public Type kind = Type.FOREGROUND;

        /// <summary>
        /// What color are we using
        /// </summary>
        public Color color = Color.WHITE;

        /// <summary>
        /// What decoration are we using, unpacked from TerminalColor.Decoration
        /// </summary>
        public (int, int) decor = (0, 30);

        /// <summary>
        /// Constructs a new terminal color object
        /// </summary>
        /// <param name="kind">The type of coloring</param>
        /// <param name="color">What color should we use</param>
        /// <param name="decor">Any optional decoration</param>
        public TerminalColor(Type kind, Color color, Decoration decor = Decoration.NONE) {
            this.kind = kind;
            this.color = color;
            this.decor = (
                (int)decor >> 16,
                (int)decor & 0xfff
             );
        }

        public override String ToString() {
            return this.kind switch {
                Type.RESET => "\e[0m",
                Type.BACKGROUND => $"\e[{40 + (int)this.color}m",
                Type.FOREGROUND => $"\e[{this.decor.Item1};{this.decor.Item2 + (int)this.color}m",
                _ => ""
            };
        }

        public static TerminalColor Reset = new TerminalColor(TerminalColor.Type.RESET, TerminalColor.Color.WHITE);
    }

    /// <summary>
    /// Contains helper functions
    /// </summary>
    public class Helpers {
        /// <summary>
        /// Repeats a String n-many times, recursive, uses many stack frames, slightly inefficient
        /// </summary>
        /// <param name="text">Arbitrary length text to repeat</param>
        /// <param name="count">Times to repeat</param>
        /// <returns></returns>
        public static String RepeatString(String text, int count) {
            if (count <= 0) { return ""; }
            return $"{text}{RepeatString(text, count - 1)}";
        }

        /// <summary>
        /// Contains box drawing characters, remember to cast to char
        /// </summary>
        public enum BoxDrawingCharacters {
            TopLeft = '┌',
            TopRight = '┐',
            BottomLeft = '└',
            BottomRight = '┘',
            Horizontal = '─',
            Vertical = '│'
        }
    }

    /// <summary>
    /// Contains printing utilities
    /// </summary>
    public class Print {
        static TerminalColor ErrorColor = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.RED, TerminalColor.Decoration.BOLD);
        static TerminalColor WarnColor = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.YELLOW, TerminalColor.Decoration.BOLD);
     
        public static void Error(String msg) {
            Console.WriteLine($"{ErrorColor}{msg}{TerminalColor.Reset}");
        }

        public static void Warn(String msg) {
            Console.WriteLine($"{WarnColor}{msg}{TerminalColor.Reset}");
        }
    }

    /// <summary>
    /// Handles user input and executing NamedQuery's
    /// </summary>
    public class Query {
        public static TerminalColor errorColor = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.RED, TerminalColor.Decoration.BOLD_HIGH_INTENSITY);

        /// <summary>
        /// Accepts a String from the user
        /// </summary>
        /// <param name="query">Query prompt</param>
        /// <returns>The output String, guaranteed to not be null</returns>
        public static String String(String query) {
            Console.Write($"{query}> ");

            String? input = Console.ReadLine();
            if (input == null) {
                return Query.String(query);
            }

            return input;
        }

        /// <summary>
        /// Accepts a String from the user, then converts it using the given function to type T
        /// </summary>
        /// <typeparam name="T">Type expected to be converted to</typeparam>
        /// <param name="query">Query prompt</param>
        /// <param name="converter">Conversion function, expected to throw an exception on failure</param>
        /// <param name="lastException">If we failed, what was the last exception</param>
        /// <returns></returns>
        public static T Any<T>(String query, Func<String, T> converter, Exception? lastException = null) {
            if (lastException != null) {
                Console.WriteLine($"\n{Query.errorColor}Error: {lastException.Message}{TerminalColor.Reset}");
            }

            String answer = Query.String(query);

            try {
                return converter(answer);
            } catch (Exception e) {
                return Query.Any<T>(query, converter, e);
            }
        }

        /// <summary>
        /// Accepts an integer from the user
        /// </summary>
        /// <param name="query">Query prompt</param>
        /// <returns></returns>
        public static int Int(String query) {
            return Query.Any<int>(query, Convert.ToInt32);
        }
    }

    /// <summary>
    /// Almost entirely identical to Query, except queries are able to fail
    /// </summary>
    public class QueryFallible {
        /// <summary>
        /// Accepts a String from the user
        /// </summary>
        /// <param name="query">Query Prompt</param>
        /// <returns></returns>
        public static String? String(String query) {
            Console.Write($"{query}> ");

            return Console.ReadLine();
        }

        /// <summary>
        /// Accepts a String from the user, then converts it using the provided function
        /// Note the constraint that T must be a value type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="query">Query Prompt</param>
        /// <param name="converter">Conversion Function</param>
        /// <returns></returns>
        public static Nullable<T> Any<T>(String query, Func<String, T> converter)
            where T: struct 
        {
            String answer = Query.String(query);
            if (answer == null) return null;
            
            try {
                return converter(answer);
            } catch {
                return null;
            }
        }
    }

    public class Splash(String name, String subtitle, String description = "") : Attribute {
        public String Name { set; get; } = name;
        public String Subtitle { set; get; } = subtitle;
        public String Description { set; get; } = description;

        static TerminalColor NameColor = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.WHITE, TerminalColor.Decoration.BOLD_HIGH_INTENSITY);

        /// <summary>
        /// Gets if a NamedQuery is a Splash as well
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        public static Splash? GetSplash(Action action) {
            return action.Method.GetCustomAttribute<Splash>();
        }

        /// <summary>
        /// Displays the Splash
        /// </summary>
        void Display() {
            Console.Clear();

            int lines = Splash.CenterVerticalLines(5);
            Console.Write(Helpers.RepeatString("\n", lines));

            Splash.WriteHorizontal(this.Name, NameColor);
            Splash.WriteHorizontal(Helpers.RepeatString(((char)Helpers.BoxDrawingCharacters.Horizontal).ToString(), this.Name.Length + 16));
            Splash.WriteHorizontal(this.Subtitle);
            Splash.WriteHorizontal(this.Description);
        }

        static String[] emotes = { ":3", "^~^", ";-;", "o:", "*-*", "n^n", ":3", ":)" };
        void DisplayEffect(int tick) {
            if (tick % 60 != 0) return;

            String selection = emotes[Random.Shared.Next(emotes.Length)];
            Console.SetCursorPosition(
                Random.Shared.Next(2, (Console.WindowWidth - 2) - selection.Length),
                Random.Shared.Next(2, Console.WindowHeight - 3)
            );
            Console.Write(selection);
        }

        /// <summary>
        /// Executes a Splash, inits a main loop
        /// </summary>
        public void Run() {
            Console.Clear();

            int w = 0;
            int h = 0;
            int count = 0;
            int tick = 0;
            while (true) {
                this.DisplayEffect(tick);

                if (w != Console.WindowWidth || h != Console.WindowHeight) {
                    w = Console.WindowWidth;
                    h = Console.WindowHeight;
                    this.Display();
                    Console.CursorVisible = false;
                }

                String headerText = " press any key to continue ";
                String header = "";

                for (int i = 0; i <= Console.WindowWidth - 2; i++) {
                    header += headerText[i % headerText.Length];
                }

                header = ((headerText[(headerText.Length - (count % headerText.Length))..]) + header)[0..(Console.WindowWidth - 1)];

                Console.SetCursorPosition(0, 0);
                Console.WriteLine(header);

                Console.SetCursorPosition(0, Console.WindowHeight - 2);
                Console.WriteLine(header);
                Console.SetCursorPosition(0, 0);

                if (Console.KeyAvailable) {
                    Console.ReadKey(true);
                    break;
                }

                if (tick % 30 == 0) count++;
                tick++;
                Thread.Sleep(10);
            }

            Console.CursorVisible = true;
        }

        static void WriteHorizontal(String text, TerminalColor? color = null) {
            if (color != null) {
                Console.Write(color);
            }
            Console.WriteLine(Splash.CenterHorizontal(text));
            Console.Write(TerminalColor.Reset);
        }

        static String CenterHorizontal(String text, int sub = 0) {
            String side = LabLib.Helpers.RepeatString(" ", (Console.WindowWidth - sub - text.Length) / 2);
            return $"{side}{text}{side}";
        }

        static int CenterVerticalLines(int lines) {
            return (Console.WindowHeight - lines) / 2;
        }
   }

    /// <summary>
    /// Named Query attribute
    /// Provides metadata for query sets
    /// </summary>
    /// <remarks>
    /// Constructs a new NamedQuery
    /// </remarks>
    /// <param name="name">Name of the query</param>
    /// <param name="desc">Optional description of the query</param>
    public class NamedQuery(String name, String desc = "No description given") : Attribute {
        internal static readonly TerminalColor headerColor = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.WHITE, TerminalColor.Decoration.BOLD_HIGH_INTENSITY);
        public class MissingNamedQueryException : Exception { };

        /// <summary>
        /// Name of the query
        /// </summary>
        public String Name { set; get; } = name;

        /// <summary>
        /// Description of the query
        /// </summary>
        public String Description { set; get; } = desc;

        /// <summary>
        /// Retrieves a NamedQuery attribute from an Action, if it's available
        /// </summary>
        /// <param name="action">Action to retrieve the attribute from</param>
        /// <returns>NamedQuery attribute, if it exists</returns>
        public static NamedQuery? GetNamedQuery(Action action) {
            return action.Method.GetCustomAttribute<NamedQuery>();
        }

        /// <summary>
        /// Prepares for a query, printing a formatted header
        /// </summary>
        internal void PrepareQuery() {
            Console.Clear();
            Console.WriteLine();

            String repeated = LabLib.Helpers.RepeatString("─", Console.WindowWidth - 4);
            String side = LabLib.Helpers.RepeatString(" ", (((Console.WindowWidth - this.Name.Length) / 2) - 2));

            Console.CursorVisible = true;
            Console.WriteLine($"{headerColor}┌{repeated}┐\n├{side}{((Console.WindowWidth + this.Name.Length) % 2 == 0 ? "" : " ")}{this.Name}{side}┤\n└{repeated}┘{TerminalColor.Reset}\n");
        }

        /// <summary>
        /// Prompts the user to go to the next query
        /// </summary>
        public void NextQuery() {
            Console.CursorVisible = false;
            String text = "Press any key to continue...";
            String side = LabLib.Helpers.RepeatString("─", ((Console.WindowWidth - text.Length) / 2) - 2);
            Console.WriteLine($"\n{headerColor}{side} {text} {side}{TerminalColor.Reset}\n");
            Console.SetCursorPosition(1, 1);
            Console.ReadKey();
            Console.Clear();
        }

        /// <summary>
        /// Executes the given Action with a NamedQuery attribute
        /// </summary>
        /// <param name="action">The function</param>
        /// <exception cref="MissingNamedQueryException"> </exception>
        public static void Run(Action action) {
            NamedQuery? query = NamedQuery.GetNamedQuery(action);

            if (query == null) {
                throw new MissingNamedQueryException();
            }

            Splash? splash = Splash.GetSplash(action);

            if (splash != null) splash.Run();

            query.PrepareQuery();
            action();
            query.NextQuery();
        }
    }

    /// <summary>
    /// Contains all parts of a lab, for menu use later
    /// </summary>
    public class Lab {
        List<Action> parts = new List<Action> { };
        Action? finisher;

        /// <summary>
        /// Adds a lab "part", a discrete lab question
        /// </summary>
        /// <param name="part">An Action with a NamedQuery attrivbute</param>
        /// <returns></returns>
        /// <exception cref="MissingNamedQueryException"></exception>
        public Lab AddPart(Action part) {
            NamedQuery? query = NamedQuery.GetNamedQuery(part);

            if (query == null) {
                throw new NamedQuery.MissingNamedQueryException();
            }

            this.parts.Add(part);

            return this;
        }

        public Lab Finisher(Action fin) {
            this.finisher = fin;
            return this;
        }

        /// <summary>
        /// Runs the entire lab, start to finish
        /// </summary>
        public void Run() {
            foreach (Action part in this.parts) {
                NamedQuery.Run(part);
            }

            if (this.finisher == null) return;
            this.finisher();
        }
    }
}
