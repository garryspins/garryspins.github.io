﻿using LabLib;

namespace Lab06 {
    internal class Program {
        static void Main() {
            new LabLib.Lab()
                .AddPart(Program.ReflectionQuestions)

                .AddPart(Lab06a.Part1)
                .AddPart(Lab06a.Part2)
                .AddPart(Lab06a.Part3)
                .AddPart(Lab06a.Part4)
                .AddPart(Lab06a.Part5)

                .AddPart(Lab06b.Part1)
                .AddPart(Lab06b.Part2)
                .AddPart(Lab06b.Part3)
                .AddPart(Lab06b.Part4)
                .AddPart(Lab06b.Part5)

                .Finisher(Program.Finisher)
                .Run();
        }

        [LabLib.NamedQuery("Lab06a / Lab06b: Reflection Questions")]
        static void ReflectionQuestions() {
            // Trying something different!

            TerminalColor header = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.WHITE, TerminalColor.Decoration.BOLD_HIGH_INTENSITY);
            TerminalColor reset = TerminalColor.Reset;
            Console.WriteLine($"   {header}Lab06a{reset}");
            Console.WriteLine($"1. {header}What is the difference between using a for-loop vs. a foreach loop with arrays{reset}");
            Console.WriteLine("   A for loop requires a lot more typing, whereas a foreach loop just requires a");
            Console.WriteLine("   simple 'in' keyword and boom. No manual indexing. A negative side effect however");
            Console.WriteLine("   is that actually retrieving the index can be painful.");
            Console.WriteLine("");
            Console.WriteLine($"2. {header}Why are arrays considered reference types, and how does that affect function behavior?{reset}");
            Console.WriteLine("   Arrays are considered 'reference types' because a variable containing an array, actually");
            Console.WriteLine("   just contains a reference to that array. Reference types are useful for objects that");
            Console.WriteLine("   are not easy to copy quickly. Since arrays have the potential to be huge, copying an");
            Console.WriteLine("   address is (in some cases) much cheaper. And it effects function behavior because");
            Console.WriteLine("   since it is passed as a reference, modifying an array actually modifies its underlying data!");
            Console.WriteLine("");
            Console.WriteLine($"3. {header}How can you find the smallest value in an array using a loop?{reset}");
            Console.WriteLine("   By having a 'min' variable, iterating through each element, and calling Math.Min(min, val)!");
            Console.WriteLine("");
            Console.WriteLine($"   {header}Lab06b{reset}");
            Console.WriteLine($"1. {header}How does a for-loop differ from a foreach loop when working with arrays?{reset}");
            Console.WriteLine("   As I stated above, syntax sugar, only real downside being missing the index, and even that");
            Console.WriteLine("   can be worked around with a custom iterator wrapper class or outer counter variable.");
            Console.WriteLine("");
            Console.WriteLine($"2. {header}Why do arrays behave as reference types in C#{reset}");
            Console.WriteLine("   As is in Lab06a.1, you want to avoid copies on big data as much as possible.");
            Console.WriteLine("");
            Console.WriteLine($"3. {header}What would happen if you passed an array to a method without modifying it?{reset}");
            Console.WriteLine("   According to the array, just a read, assuming what you do in that method is read it.");
            Console.WriteLine("   No modification done is no modification done.");
        }

        class Star {
            public int x;
            public int y;
            public int brightness;
            public int offset;
        }

        static void Finisher() {
            TerminalColor bold = new TerminalColor(TerminalColor.Type.FOREGROUND, TerminalColor.Color.WHITE, TerminalColor.Decoration.BOLD_HIGH_INTENSITY);
            List<Star> stars = new List<Star>();

            for (int i = 0; i < 200; i++) {
                stars.Add(new Star {
                    x = Random.Shared.Next(1, Console.WindowWidth - 2),
                    y = Random.Shared.Next(1, Console.WindowHeight - 2),
                    brightness = Random.Shared.Next(1, 4),
                    offset = Random.Shared.Next(1, 1000)
                });
            }

            Console.CursorVisible = false;
            int tick = 0;
            String text = "  Press any key to exit  ";
            while (true) {
                tick++;

                foreach (Star star in stars) {
                    Console.SetCursorPosition(star.x, star.y);
                    Console.Write(star.brightness switch {
                        1 => "·",
                        2 => "-",
                        3 => $"{bold}*{TerminalColor.Reset}",
                        _ => "",
                    });

                    star.brightness = (int)((Math.Sin((tick / 100) + star.offset)) * 4);
                }

                Console.SetCursorPosition(Console.WindowWidth / 2 - text.Length / 2, Console.WindowHeight / 2);
                Console.Write(text);

                if (Console.KeyAvailable) {
                    Console.ReadKey();
                    Console.Clear();
                    System.Environment.Exit(0);
                }

                Thread.Sleep(50);
            }
        }
    }

    class Lab06a {
        [LabLib.NamedQuery("Lab06a / Part 1: Creating and Accessing an Array")]
        [LabLib.Splash("Lab06a", "Loops and Arrays in C#", "Waow! I really list List<T>")]
        public static void Part1() {
            // Heres the naive way of doing it
            // yk.. for proof I can
            //int[] nums = new int[5] {
            //    LabLib.Query.Int("Please enter a number (1)"),
            //    LabLib.Query.Int("Please enter a number (2)"),
            //    LabLib.Query.Int("Please enter a number (3)"),
            //    LabLib.Query.Int("Please enter a number (4)"),
            //    LabLib.Query.Int("Please enter a number (5)"),
            //};

            Console.WriteLine("Enter any amount of numbers you'd like! To stop entering numbers, press enter.");
            List<int> nums = new List<int>();
            int max = 0;
            while (true) {
                int? num = LabLib.QueryFallible.Any<int>($"Please enter a number (#{nums.Count + 1})", Convert.ToInt32);
                if (num == null) { break; }

                nums.Add((int)num);
                max = Math.Max(max, (int)num);
            }

            nums.Reverse();

            foreach (int num in nums) {
                Console.WriteLine(num);
            }

            Console.WriteLine($"Largest number is {max}");
        }

        [LabLib.NamedQuery("Lab06a / Part 2: Using a While-Loop with Arrays")]
        public static void Part2() {
            List<String> names = new List<String>();
            int? isExited = null;

            for (int i = 0; i < 5; i++) {
                String name = LabLib.Query.String($"Please enter a name (#{i + 1})");
                isExited = name == "exit" ? i : isExited;
                if (!name.Contains('a')) continue;

                names.Add(name);
            }

            int j = 0;
            while (j < Math.Min(isExited == null ? names.Count : (int)isExited, names.Count)) {
                Console.WriteLine($"[{j + 1}] {names[j]}");
                j++;
            }
        }

        [LabLib.NamedQuery("Lab06a / Part 3: Using a Do-While loop with Arrays")]
        // This ones a REAL mess!
        public static void Part3() {
            List<int> scores = new List<int>();
            int sum = 0;

            do {
                String scoreStr = LabLib.Query.String("Please enter a score (-1 to exit)");
                int? scoreNull = null;

                if (scoreStr == "stop") scoreNull = -1;

                try {
                    if (scoreNull == null) scoreNull = Convert.ToInt32(scoreStr);
                }
                catch { continue; }

                int score = (int)scoreNull;
                if (Math.Clamp(score, -1, 100) != score) {
                    LabLib.Print.Warn("Scores must be between 0 and 100");
                    continue;
                }

                scores.Add(score);

                if (score != -1) sum += score;
                if (scores.Count >= 10) break; // I'm just cheating here, fuck loop conditions amirite, nested ternaries are GAY
            } while (scores.Count > 0 ? scores.Last() != -1 : true);

            Console.WriteLine($"{String.Join(", ", scores[0..(scores.Count - 1)])}");
        
            try {
                Console.WriteLine($"Avg: {sum / (scores.Count - 1)}");
            } catch {
                Console.WriteLine("Cannot calculate avg, 0 elements");
            }
        }

        [LabLib.NamedQuery("Lab06a / Part 4: Using Foreach with Arrays")]
        public static void Part4() {
            List<String> words = new List<String>();

            while (true) {
                String word = LabLib.Query.String("Enter a word (stop to exit)").ToUpper();

                if (word.Length == 0) continue;
                if (word == "STOP") break;
                if (word[0] != 'B') continue;

                words.Add(word);
            }

            foreach (String word in words) {
                Console.WriteLine(word);
            }

            Random rand = new Random();
            List<int> randNums = new List<int>();
            for (int i = 0; i < 10; i++) {
                int r = rand.Next() % 100;
                if (r % 2 != 0) continue;
                randNums.Add(r);
            }

            Console.WriteLine(String.Join(", ", randNums));
        }

        [LabLib.NamedQuery("Lab06a / Part5: Reference Types & Memory")]
        public static void Part5() {
            static int[] ModifyArray(int[] arr) {
                int[] newArr = new int[arr.Length];
                for (int i = 0; i < arr.Length; i++) {
                    newArr[i] = arr[i] * 2;
                }
                return newArr;
            }

            static void DontModifyArray(int val) {
                val = 10; // DOES NOTHING!!! :3
            }

            int[] arr = {
                LabLib.Query.Int("Enter an integer (1)"),
                LabLib.Query.Int("Enter an integer (2)"),
                LabLib.Query.Int("Enter an integer (3)"),
                LabLib.Query.Int("Enter an integer (4)"),
                LabLib.Query.Int("Enter an integer (5)"),
            };

            int[] newArr = ModifyArray(arr);
            DontModifyArray(arr[2]); // USELESSSS!!!!!!!!! INTS ARE COPYY

            Console.WriteLine(String.Join(", ", newArr));
        }
    }

    class Lab06b {
        [LabLib.NamedQuery("Lab06b / Part 1: Creating and Accessing an array")]
        [LabLib.Splash("Lab06b", "Working with Arrays and Reference Types in C#", "Reference types are a liberal lie.")] // new feature, splashes!
        public static void Part1() {
            List<int> nums = new List<int>();
            int? min = null;

            for (int i = 0; i < 5; i++) {
                int num = LabLib.Query.Int($"Please enter an integer ({i + 1})");
                min = Math.Min(min == null ? num : (int)min, num);
                nums.Add(num);
            }

            nums.Reverse();
            Console.WriteLine(String.Join(", ", nums));
            Console.WriteLine($"Min value: {min}");
        }

        [LabLib.NamedQuery("Lab06b / Part 2: Iterating with For-Each Loops")]
        public static void Part2() {
            List<String> names = new List<String>();

            for (int i = 0; i < 5; i++) {
                String name = LabLib.Query.String($"Please enter a name ({i + 1})");
                if (!name.Contains("e", StringComparison.InvariantCultureIgnoreCase)) continue;
                names.Add(name.ToUpper());
            }

            foreach (String name in names) {
                Console.WriteLine(name);
            }
        }

        [LabLib.NamedQuery("Lab06b / Part 3: Reference Types and Arrays")]
        public static void Part3() {
            Lab06a.Part5();
        }

        [LabLib.NamedQuery("Lab06b / Part 4: Finding Maximum and Minimum values in an Array")]
        public static void Part4() { // did it without an array, suck it
            int? min = null;
            int count = 0;
            int total = 0;

            for (int i = 0; i < 10; i++) {
                int num = LabLib.Query.Int($"Please enter an integer ({i + 1})");
                count += 1;
                total += num;
                min = Math.Min(min == null ? num : (int)min, num);
            }

            Console.WriteLine($"Min: {min}");
            Console.WriteLine($"Avg: {total / count}");
        }

        [LabLib.NamedQuery("Lab06b / Part 5: Summing Array Elements with a For-Loop")]
        public static void Part5() {
            // This lab is so repetitive

            int[] nums = {
                LabLib.Query.Int("Please enter an integer (1)"),
                LabLib.Query.Int("Please enter an integer (2)"),
                LabLib.Query.Int("Please enter an integer (3)"),
                LabLib.Query.Int("Please enter an integer (4)"),
                LabLib.Query.Int("Please enter an integer (5)"),
            };

            int evenTotal = 0;
            int overTenTotal = 0;

            foreach (int num in nums) {
                if (num % 2 == 0) evenTotal += num;
                if (num > 10) overTenTotal += num;
            }

            Console.WriteLine($"Even total: {evenTotal}");
            Console.WriteLine($"Over Ten total: {overTenTotal}");
        }
    }
}
